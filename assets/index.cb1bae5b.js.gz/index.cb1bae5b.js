import{l as e,R as a,s as t}from"./vendor.dce33a88.js";import{D as r}from"./Disclaimer.d572b129.js";import{H as n}from"./Header.80fac76e.js";const s=()=>{const{t:t}=e("disclaimer");return a.createElement(c,null,a.createElement(n,{backPath:"/",name:t("name")}),a.createElement("h3",null,t("message.you_accepted")),a.createElement(r,null))},c=t.div`
  width: 100%;
  text-align: center;
  background-color: #fff;
  height: 100%;

  & p {
    padding: 0 16px;
    font-size: 12px;
  }
`;export{s as default};
